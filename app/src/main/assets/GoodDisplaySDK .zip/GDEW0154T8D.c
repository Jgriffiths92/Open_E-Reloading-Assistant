#include "project.h"
#include "auth_key.h"

TaskHandle_t		 		SYSCORE_id;																		// CORE task handle
TaskHandle_t		 		SYSAUX_id;																		// AUX task handle

uint8_t nfc_rx_buf[128] __attribute__( ( section( "NoInit"),zero_init) );	
uint8_t nfc_tx_buf[128] __attribute__( ( section( "NoInit"),zero_init) );
uint8_t ucHeap[ configTOTAL_HEAP_SIZE ] __attribute__( ( section( "NoInit"),zero_init) );
uint8_t 		pic_buffer[128] __attribute__( ( section( "NoInit"),zero_init) );

uint8_t data_length;
uint8_t eink_step = 0;
bool    eink_reflash_flag = false;
bool    eink_ok_flag = false;
bool    eink_ok = false;

bool   auto_refresh=false;
TaskHandle_t		 		Main_id;																			// user's task handle
void osMain_task(void);


int main(void)
{	
	init_core_components();																					// initiate the key system components
	NFC_SYS_PWR_DRN(false);
	NFC_RX_CB_EVT_SET(false); 	
 // SET_BIT(NFC->MODULECTRL, NFC_MODULECTRL_CLKCALIBEN_Msk);     
    NFC->POWER = 0xc6;  //this must be needed,otherwise busy pin will not get high level
     
	EINK_PINMODE_INIT();
	EINK_GPIO_INIT();  
  EINK_POWER_EN();
	xTaskCreate( (TaskFunction_t)osMain_task, "Main", 96, NULL, 9, &Main_id );									// create the user's task	
	
	osLaunchRTOS();
	vTaskStartScheduler();				
																									// create key system tasks and launch the RTOS
	while(1);																												// should never reach here
}
/// Application task which is the main body of the demo for eink display control. FreeRTOS will allocate CPU time for this task automatically. 
void osMain_task()																								// user's task
{
	osCreateAuth();																									// Create the authentication task
	while(1)																												// code must be placed in a never-ending loop
	{

		if(eink_reflash_flag)
		{
			EINK_POWER_EN(); //4.2��������Ҫ���������ã�������ܵ�����;�ϵ�
			vTaskDelay(1000); //�ȴ�DC/DC��λ��ɡ�
			SPI_WriteCMD(0x12);			//DISPLAY REFRESH 
			eink_reflash_flag=false; 
			eink_ok_flag=true;
		}
		if(eink_ok)
		{
			SPI_WriteCMD(0X02);  	//Power off
			SPI_WriteCMD(0X07);  	//deep sleep
		  SPI_WriteDATA(0xA5);
		//	LED_ON();	
			eink_ok_flag=false;
			eink_ok=false;
		}
		if(eink_ok_flag)
		{
		//	LED2_ON();
			vTaskDelay(3);
		//	LED2_OFF();
		}
		vTaskDelay(200);																							// delay 100ms  	  
	}
}
void NFC_RX_Callback()																															// called every time a command is received
{
	if (NFC_Passthrough_RX(nfc_rx_buf))																								// check if it's a type 4 command
	{
		nfc_tx_buf[0] = 0x01;                                                           //Return two bytes of data to the reader
		nfc_tx_buf[1] = 0x02;	
	 if (nfc_rx_buf[0] == 0xcd) 																										// 0xcd: eink control
		{
			if (nfc_rx_buf[1] == 0x80)
			{
				SCL_L;                                                                      //pin init and eink rest
				SDA_H;
				CSB_H;
				RSTN_L;	
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}		
			else if (nfc_rx_buf[1] == 0x81) 
			{
				RSTN_H;
				NFC_Passthrough_TX(nfc_tx_buf, 2); 
			}
			else if (nfc_rx_buf[1] == 0x82)
			{
				eink_step=2;
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x83)
			{
				SPI_WriteCMD(0x10);
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x84)
			{
				SPI_WriteCMD(0x13);
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x85)
			{
				eink_step=3;
				data_length=nfc_rx_buf[2];
				memcpy(pic_buffer, &nfc_rx_buf[3], data_length);
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x86)
			{
				eink_reflash_flag=true;	
				NFC_Passthrough_TX(nfc_tx_buf, 2);				
			}
			else if (nfc_rx_buf[1] == 0x87)
			{
				if(BUSYN){
					nfc_tx_buf[0] = 0xff;
				} 
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x88)
			{
				if(!BUSYN) 
				{
					nfc_tx_buf[0] = 0xff;
					eink_ok = true;
				}
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x89)
			{
				check_busy_high();
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x8a)
			{
				check_busy_low();
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x8c)
			{
				//EINK_POWER_DIS();
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x8d)
			{
				eink_step=1;
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			
			else if (nfc_rx_buf[1] == 0x90)   //Reserved interface
			{
				SPI_WriteCMD(nfc_rx_buf[2]);	
				NFC_Passthrough_TX(nfc_tx_buf, 2);				
			}
			else if (nfc_rx_buf[1] == 0x91)   //Reserved interface
			{
				SPI_WriteDATA(nfc_rx_buf[2]);
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			
			else if (nfc_rx_buf[1] == 0x92)   //led0 on
			{
//				LED_ON();						
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x93)   //led0 off
			{
//				LED_OFF();
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			
			else if (nfc_rx_buf[1] == 0x94)   //led0 on
			{
//				LED2_ON();	
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if (nfc_rx_buf[1] == 0x95)   //led0 off
			{
//				LED2_OFF();
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
			else if(nfc_rx_buf[1]	==	0xff)                                       //password setting and authentication  
			{
				nfc_tx_buf[0] = 0xff;                                                           //Return two bytes of data to the reader
				nfc_tx_buf[1] = 0xff;
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
		}
		// 0xbd: NFC OTA FW update mode
		else if ((nfc_rx_buf[0] == 0xbb)&&(Auth_other_status()))
		{
			if (memcmp(&nfc_rx_buf[1],"BOOT", 4)==0)
			{
				nfc_tx_buf[0] = 0xbb;
				nfc_tx_buf[1] = 'O';
				nfc_tx_buf[2] = 'K';
				
				NFC_Passthrough_TX(nfc_tx_buf, 3);
				vTaskDelay(5);
				enter_OTA();
			}
		}
				//card status calibration
		else if(nfc_rx_buf[0] == 0x0b){
			if (nfc_rx_buf[1] == 0xb0){
				nfc_tx_buf[0] = 0xff;
				nfc_tx_buf[1] = 0xff;
				
				NFC_Passthrough_TX(nfc_tx_buf, 2);
			}
		}		
		else if (nfc_rx_buf[0] == 0xbc)																									// FW version inquiry
		{
			if (nfc_rx_buf[1] == 0xcd)																										// bootloader version
			{
				memcpy(&nfc_tx_buf[0], (void *)(0x00001560), 6);
				NFC_Passthrough_TX(nfc_tx_buf, 6);
			}
			else if (nfc_rx_buf[1] == 0xc0)																								// oslib version
			{
				memcpy(&nfc_tx_buf[0], (void *)(0x00002040), 24);
				NFC_Passthrough_TX(nfc_tx_buf, 24);
				
			}
			else if (nfc_rx_buf[1] == 0xc1)																								// Application FW version
			{
				memcpy(&nfc_tx_buf[0], (void *)(0x00006600), 24);
				NFC_Passthrough_TX(nfc_tx_buf, 24);
				
			}
			else if (nfc_rx_buf[1] == 0xc2)																								// Application built number
			{
				memcpy(&nfc_tx_buf[0], (void *)(0x00002000), 24);
				NFC_Passthrough_TX(nfc_tx_buf, 24);
				
			}
		}
		else if (nfc_rx_buf[0] == 0xae) // authentication
		{
			if (nfc_rx_buf[1] == 'A')
			{
				if (nfc_rx_buf[2] == 'I')																											// initial request
				{
					Auth_process(0, &nfc_rx_buf[3]);
			
					nfc_tx_buf[0] = 0xae;
          nfc_tx_buf[1] = 'O';
          nfc_tx_buf[2] = 'K';
                    
          NFC_Passthrough_TX(nfc_tx_buf, 3);
				}
				else if (nfc_rx_buf[2] == 'Q')																									// query status
				{
					if (Auth_engine_busy(0))
					{
						nfc_tx_buf[0] = 0xae;
						nfc_tx_buf[1] = 'O';
						nfc_tx_buf[2] = 'K';
						
						memcpy(&nfc_tx_buf[3], Auth_get_self_response(), 20);
						NFC_Passthrough_TX(nfc_tx_buf, 23);
					}
					else
					{
						nfc_tx_buf[0] = 0xae;
						nfc_tx_buf[1] = 'B';
						nfc_tx_buf[2] = 'S';
						NFC_Passthrough_TX(nfc_tx_buf, 3);
					}
					
				}
			}
			else if (nfc_rx_buf[1] == 'F')
			{
				if (nfc_rx_buf[2] == 'I')                                                                                                        // initial request
        {
					
					nfc_tx_buf[0] = 0xae;
					nfc_tx_buf[1] = 'O';
					nfc_tx_buf[2] = 'K';
					Auth_process(1, &nfc_tx_buf[3]);
					
					NFC_Passthrough_TX(nfc_tx_buf, 23);

				}
				else if (nfc_rx_buf[2] == 'U')                                                                                            // unlock request
				{
					if (Auth_engine_busy(1))
					{
						nfc_tx_buf[0] = 0xae;
						Auth_process(1, &nfc_rx_buf[3]);																								
						if (Auth_other_status())
						{
							nfc_tx_buf[1] = 'O';
							nfc_tx_buf[2] = 'K';
								
						}
						else
						{
							nfc_tx_buf[1] = 'F';
							nfc_tx_buf[2] = 'L';
						}
						NFC_Passthrough_TX(nfc_tx_buf, 3);
					}
					else
					{
							nfc_tx_buf[0] = 0xae;
							nfc_tx_buf[1] = 'B';
							nfc_tx_buf[2] = 'S';
							
							NFC_Passthrough_TX(nfc_tx_buf, 3);
					}
				}    				
			}			
		}
		
	}	
}

/**
 * @brief NFC transmission callback. 
 *
 * Invoked whenever there is data transmitted from the NFC. 
 * A custom command set is adopted to control the process of eink flashing.
 */
void NFC_TX_Callback()	
{
	
	if(eink_step!=0)
	{
		//LED2_ON();
		if(eink_step==1)
		{
			vTaskDelay(4);
			#ifdef SPI_4BUS
			//EINK_POWER_EN();
			#endif
		}
		else if(eink_step==2)
		{
			SPI_WriteCMD(0x04);  
			vTaskDelay(10); //waiting for the electronic paper IC to release the idle signal

			SPI_WriteCMD(0x00);			//panel setting
			SPI_WriteDATA(0x0f);		//LUT from OTP
		
		  SPI_WriteCMD(0X50);			//VCOM AND DATA INTERVAL SETTING			
			SPI_WriteDATA(0x77);		//WBmode:VBDF 17|D7 VBDW 97 VBDB 57		WBRmode:VBDF F7 VBDW 77 VBDB 37  VBDR B7	
		}
		else if(eink_step==3)
		{
			for(uint8_t i=0;i<data_length;i++)
			{
				SPI_WriteDATA(pic_buffer[i]);
			}
		}
		eink_step=0; 
   	

	}
	
	
}
/**
 * @brief NFC field off callback. 
 *
 * Invoked whenever the NFC field goes undetectible. 
 */
__attribute__((section("RW_IRAM1"))) void NFC_FIELD_OFF_Callback()
{
	eink_step = 0;
  eink_reflash_flag = false;   
  eink_ok_flag = false;
  eink_ok = false;

}	
/**
 * @brief User get unique num callback. 
 *
 * Invoked whenever authentication Initialization is done. 
 */
uint32_t get_unique_num_callback()
{
	uint32_t val;
	nv_counter_get(NULL, &val);
	
	return 0;
}
/**
 * @brief User reset unique num callback. 
 *
 * Invoked whenever authentication process is doing. 
 */
void reset_unique_num_callback()
{
	nv_counter_tick();
	
}

